// Based on
// Chapter 41 - GPGPU Flow Field Particles
// threejs-journey.com
// by Bruno Simon


import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
// import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
// import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js'
import { GPUComputationRenderer } from 'three/addons/misc/GPUComputationRenderer.js'
import GUI from 'lil-gui'

import particlesVertexShader from './shaders/particles_solution.vert';
import particlesFragmentShader from './shaders/particles_solution.frag';
import textureParticlesShader from './shaders/gpgpu/textureParticles_solution.glsl';


//// GUI
// const gui = new GUI({ width: 340 });
const gui = new GUI();
const guiData = {};

guiData.clearColor = '#000000';


//// Canvas
const canvas = document.querySelector("#canvasThree");

//// Scene
const scene = new THREE.Scene();

//// Geometry Loaders
// Draco Compression
// (only needed when using a glb file)
// const dracoLoader = new DRACOLoader();
// dracoLoader.setDecoderPath('/draco/');

// const gltfLoader = new GLTFLoader();
// gltfLoader.setDRACOLoader(dracoLoader);

//// Loading the Model
// const gltf = await gltfLoader.loadAsync('./model.glb');
// const gltf = await gltfLoader.loadAsync('./Star.glb');



//// Helper
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight,
    pixelRatio: Math.min(window.devicePixelRatio, 2)
};



//// Camera
const camera = new THREE.PerspectiveCamera(35, sizes.width / sizes.height, 0.1, 100);
camera.position.set(4, 1, 12);
scene.add(camera);


//// Controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;


//// Renderer
const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    antialias: true,
});
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(sizes.pixelRatio);


renderer.setClearColor(guiData.clearColor);



//// GEOMETRY
const baseGeometry = {};
// baseGeometry.mesh = gltf.scene.children[0].geometry;
baseGeometry.mesh = new THREE.SphereGeometry(1, 128, 128);
baseGeometry.count = baseGeometry.mesh.attributes.position.count;


//// GPGPU COMPUTE
// https://github.com/mrdoob/three.js/blob/8286a475fd8ee00ef07d1049db9bb1965960057b/examples/jsm/misc/GPUComputationRenderer.js

// Setup
const gpgpu = {};

// Size of the "framebuffer
gpgpu.size = Math.ceil(Math.sqrt(baseGeometry.count));

// Create GPGPU Computation Renderer
gpgpu.computation = new GPUComputationRenderer(gpgpu.size, gpgpu.size, renderer);


// Create the "Texture-Memory" framebuffer
const textureParticles = gpgpu.computation.createTexture();
// console.log(textureParticles);
// console.log(textureParticles.image.data);


// Writing into the rgba channels of the textureParticles texture
// The required access is textureParticles.image.data and
// that is a 1D array.
for(let i = 0; i < baseGeometry.count; i++){

    const i3 = i * 3;
    const i4 = i * 4;

    // The textureParticles r channel
    // The x position of mesh point i
    textureParticles.image.data[i4 + 0] = 
                                    baseGeometry.mesh.attributes.position.array[i3 + 0];
    
    // The textureParticles g channel
    // The y position of mesh point i
    textureParticles.image.data[i4 + 1] = 
                                    baseGeometry.mesh.attributes.position.array[i3 + 1];
    
    // The textureParticles b channel
    // The z position of mesh point i
    textureParticles.image.data[i4 + 2] = 
                                    baseGeometry.mesh.attributes.position.array[i3 + 2];

    // The textureParticles b channel
    textureParticles.image.data[i4 + 3] = Math.random();

}


// Add the Texture Variables to the GPGPU Computation Renderer
// This will be a uniform sampler2D in the shader
gpgpu.particlesVariable = gpgpu.computation.addVariable('uTextureParticles', textureParticlesShader, textureParticles);
// Add variable dependencies
// Which shader needs to know from which other shader?
// Most often a variable will need itself as dependency
gpgpu.computation.setVariableDependencies(gpgpu.particlesVariable, [ gpgpu.particlesVariable ]);


//// Uniforms 
// Adding custom uniforms for textureParticlesShader
// in the same syntax as needed for three.js's ShaderMaterial
gpgpu.particlesVariable.material.uniforms.uTime = new THREE.Uniform(0);
gpgpu.particlesVariable.material.uniforms.uBase = new THREE.Uniform(textureParticles);
gpgpu.particlesVariable.material.uniforms.uDeltaTime = new THREE.Uniform(0);
gpgpu.particlesVariable.material.uniforms.uFlowFieldInfluence = new THREE.Uniform(0.5);
gpgpu.particlesVariable.material.uniforms.uFlowFieldStrength = new THREE.Uniform(2);
gpgpu.particlesVariable.material.uniforms.uFlowFieldFrequency = new THREE.Uniform(0.5);


///// Init
// Initialize the gpgpu computation
// and check for completeness
const error = gpgpu.computation.init();
if ( error !== null ) {
    console.error( error );
}

//// Optional for debugging
// Displaying the computed texture
// on a plane mesh
gpgpu.debug = new THREE.Mesh(
    new THREE.PlaneGeometry(3, 3),
    // Assigning the "texture-memory" as texture map
    // Accessing: gpgpu.computation.getCurrentRenderTarget( ).texture 
    // The current texture variable: gpgpu.particlesVariable
    new THREE.MeshBasicMaterial({ map: gpgpu.computation.getCurrentRenderTarget(gpgpu.particlesVariable).texture })
);
gpgpu.debug.visible = false; // Set to true for display
gpgpu.debug.position.x = 5;
scene.add(gpgpu.debug);




//// PARTICLES
// The following prepares all data needed
// for doing the particle simulation in the
// gpgpu shader

const particles = {};

// Data Computation
const particlesUvArray = new Float32Array(baseGeometry.count * 2);
const sizesArray = new Float32Array(baseGeometry.count);


for (let y = 0; y < gpgpu.size; y++) {
    for (let x = 0; x < gpgpu.size; x++) {

        // Coordinates for 1D, 2D and 3D arrays
        const i = (y * gpgpu.size) + x; // Size array
        const i2 = i * 2;               // UV array

        // The UV coordinates of the "memory-texture"
        // for each particle
        const uvX = (x + 0.5) / gpgpu.size;
        const uvY = (y + 0.5) / gpgpu.size;

        particlesUvArray[i2 + 0] = uvX;
        particlesUvArray[i2 + 1] = uvY;

        // A random size for each particle
        sizesArray[i] = Math.random();

    }
    
}


// A BufferGeometry object is more efficient
// to pass all this data to the GPU.
particles.geometry = new THREE.BufferGeometry();

// Setting the number of vertices to render
// with 0 as start
particles.geometry.setDrawRange(0, baseGeometry.count);

// Adding attributes to the geometry
// This is more efficient than the attributes property
// because an internal hashmap of .attributes is maintained 
// to speed up iterating over attributes. 
particles.geometry.setAttribute('aParticlesUv', new THREE.BufferAttribute(particlesUvArray, 2));
particles.geometry.setAttribute('aSize', new THREE.BufferAttribute(sizesArray, 1));

// The known ShaderMaterial setup
// piping data into and applying
// vertex and fragment shader
particles.material = new THREE.ShaderMaterial({
    depthWrite: false,
    // blending: THREE.AdditiveBlending,
    // vertexColors: true,
    vertexShader: particlesVertexShader,
    fragmentShader: particlesFragmentShader,
    uniforms:
    {
        uSize: new THREE.Uniform(0.06),
        uResolution: new THREE.Uniform(new THREE.Vector2(sizes.width * sizes.pixelRatio, sizes.height * sizes.pixelRatio))
    }
})

// Points
// Adding the template to the scene
// One point per mesh vertex
// particles.points = new THREE.Points(baseGeometry.mesh, particles.material);
particles.points = new THREE.Points(particles.geometry, particles.material);
scene.add(particles.points);


//// UI Controls
// All data is piped into the shaders as uniforms,
// hence the naming

const folderSim = gui.addFolder( 'Simulation' );

folderSim.add(particles.material.uniforms.uSize, 'value').min(0).max(1).step(0.001).name('uSize');
folderSim.add(gpgpu.particlesVariable.material.uniforms.uFlowFieldInfluence, 'value').min(0).max(1).step(0.001).name('uFlowFieldInfluence');
folderSim.add(gpgpu.particlesVariable.material.uniforms.uFlowFieldStrength, 'value').min(0).max(10).name('uFlowFieldStrength');
folderSim.add(gpgpu.particlesVariable.material.uniforms.uFlowFieldFrequency, 'value').min(0).max(1).step(0.001).name('uFlowFieldFrequency');


const folderColors = gui.addFolder( 'Colors' );
folderColors.addColor(guiData, 'clearColor').onChange(() => { 
    renderer.setClearColor(guiData.clearColor) 
});


//// Window Resize Management
window.addEventListener('resize', () =>
    {
        // Update sizes
        sizes.width = window.innerWidth;
        sizes.height = window.innerHeight;
        sizes.pixelRatio = Math.min(window.devicePixelRatio, 2);
    
        // Materials
        particles.material.uniforms.uResolution.value.set(sizes.width * sizes.pixelRatio, sizes.height * sizes.pixelRatio);
    
        // Update camera
        camera.aspect = sizes.width / sizes.height;
        camera.updateProjectionMatrix();
    
        // Update renderer
        renderer.setSize(sizes.width, sizes.height);
        renderer.setPixelRatio(sizes.pixelRatio);
    })


//// Scene Render Loop

// Scene time
const clock = new THREE.Clock();
let previousTime = 0;

const renderScene = () => {

    // Updating the current time variables
    const elapsedTime = clock.getElapsedTime();
    const deltaTime = elapsedTime - previousTime;
    previousTime = elapsedTime;
    
    // Update controls
    controls.update();

    // GPGPU Updates
    // Updating the uniforms
    gpgpu.particlesVariable.material.uniforms.uTime.value = elapsedTime;
    gpgpu.particlesVariable.material.uniforms.uDeltaTime.value = deltaTime;

    // Computing the texture processing
    gpgpu.computation.compute();

    // Updating texture to the swapped texture 
    // that is now being rendered, which
    // the gpu renderer output returns
    particles.material.uniforms.uParticleUvsTexture.value = gpgpu.computation.getCurrentRenderTarget(gpgpu.particlesVariable).texture;


    // Render
    renderer.render(scene, camera);

    // Call renderScene() again on the next frame
    window.requestAnimationFrame(renderScene);
}

renderScene();