// Based on
// Chapter 41 - GPGPU Flow Field Particles
// threejs-journey.com
// by Bruno Simon


import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
// import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
// import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js'
import GUI from 'lil-gui'

import particlesVertexShader from './shaders/particles.vert';
import particlesFragmentShader from './shaders/particles.frag';



//// GUI
// const gui = new GUI({ width: 340 });
const gui = new GUI();
const guiData = {};

guiData.clearColor = '#000000';


//// Canvas
const canvas = document.querySelector("#canvasThree");

//// Scene
const scene = new THREE.Scene();

//// Geometry Loaders
// Draco Compression
// (only needed when using a glb file)
// const dracoLoader = new DRACOLoader();
// dracoLoader.setDecoderPath('/draco/');

// const gltfLoader = new GLTFLoader();
// gltfLoader.setDRACOLoader(dracoLoader);

//// Loading the Model
// const gltf = await gltfLoader.loadAsync('./model.glb');
// const gltf = await gltfLoader.loadAsync('./Star.glb');



//// Helper
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight,
    pixelRatio: Math.min(window.devicePixelRatio, 2)
};



//// Camera
const camera = new THREE.PerspectiveCamera(35, sizes.width / sizes.height, 0.1, 100);
camera.position.set(4, 1, 12);
scene.add(camera);


//// Controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;


//// Renderer
const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    antialias: true,
});
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(sizes.pixelRatio);


renderer.setClearColor(guiData.clearColor);



//// GEOMETRY
const baseGeometry = {};
// baseGeometry.mesh = gltf.scene.children[0].geometry;
baseGeometry.mesh = new THREE.SphereGeometry(1, 128, 128);

//// GPGPU COMPUTE
// https://github.com/mrdoob/three.js/blob/8286a475fd8ee00ef07d1049db9bb1965960057b/examples/jsm/misc/GPUComputationRenderer.js

// Setup
const gpgpu = {};



//// PARTICLES

const particles = {};

// Geometry
particles.geometry = new THREE.SphereGeometry(3);

// The known ShaderMaterial setup
// piping data into and applying
// vertex and fragment shader
particles.material = new THREE.ShaderMaterial({
    depthWrite: false,
    // blending: THREE.AdditiveBlending,
    // vertexColors: true,
    vertexShader: particlesVertexShader,
    fragmentShader: particlesFragmentShader,
    uniforms:
    {
        uSize: new THREE.Uniform(0.06),
        uResolution: new THREE.Uniform(new THREE.Vector2(sizes.width * sizes.pixelRatio, sizes.height * sizes.pixelRatio)),
        uParticleUvsTexture: new THREE.Uniform() // Set in the render loop
    }
})

// Points
// Adding the template to the scene
// One point per mesh vertex

// This line would be needed if if would load a glb model:
// particles.points = new THREE.Points(baseGeometry.mesh, particles.material); 

particles.points = new THREE.Points(particles.geometry, particles.material);
scene.add(particles.points);


//// UI Controls
// All data is piped into the shaders as uniforms,
// hence the naming

const folderSim = gui.addFolder( 'Simulation' );

folderSim.add(particles.material.uniforms.uSize, 'value').min(0).max(1).step(0.001).name('uSize');
// folderSim.add(gpgpu.particlesVariable.material.uniforms.uFlowFieldInfluence, 'value').min(0).max(1).step(0.001).name('uFlowFieldInfluence');
// folderSim.add(gpgpu.particlesVariable.material.uniforms.uFlowFieldStrength, 'value').min(0).max(10).name('uFlowFieldStrength');
// folderSim.add(gpgpu.particlesVariable.material.uniforms.uFlowFieldFrequency, 'value').min(0).max(1).step(0.001).name('uFlowFieldFrequency');


const folderColors = gui.addFolder( 'Colors' );
folderColors.addColor(guiData, 'clearColor').onChange(() => { 
    renderer.setClearColor(guiData.clearColor) 
});


//// Window Resize Management
window.addEventListener('resize', () =>
    {
        // Update sizes
        sizes.width = window.innerWidth;
        sizes.height = window.innerHeight;
        sizes.pixelRatio = Math.min(window.devicePixelRatio, 2);
    
        // Materials
        particles.material.uniforms.uResolution.value.set(sizes.width * sizes.pixelRatio, sizes.height * sizes.pixelRatio);
    
        // Update camera
        camera.aspect = sizes.width / sizes.height;
        camera.updateProjectionMatrix();
    
        // Update renderer
        renderer.setSize(sizes.width, sizes.height);
        renderer.setPixelRatio(sizes.pixelRatio);
    })


//// Scene Render Loop

// Scene time
const clock = new THREE.Clock();
let previousTime = 0;

const renderScene = () => {

    // Updating the current time variables
    const elapsedTime = clock.getElapsedTime();
    const deltaTime = elapsedTime - previousTime;
    previousTime = elapsedTime;
    
    // Update controls
    controls.update();

    // Render
    renderer.render(scene, camera);

    // Call renderScene() again on the next frame
    window.requestAnimationFrame(renderScene);
}

renderScene();